package com.company;

public class Furniture {
    private int tables;
    private int chiers;
    private String cupboard_company_name;
    private String Bed_company;
    private  String sofa;

    public Furniture(int tables, int chiers, String cupboard_company_name, String bed_company, String sofa) {
        this.tables = tables;
        this.chiers = chiers;
        this.cupboard_company_name = cupboard_company_name;
        Bed_company = bed_company;
        this.sofa = sofa;
    }
    public void color(String Color_name){
        System.out.println("Room is color by "+Color_name);
    }
}
