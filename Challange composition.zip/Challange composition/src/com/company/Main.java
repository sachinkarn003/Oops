package com.company;

public class Main {

    public static void main(String[] args) {
     Electronic electronic = new Electronic(2,2,4);
     Furniture furniture = new Furniture(1,4,"LG","wakefit","usha");
     Room_element room_element = new Room_element(1,10,8);
     Room room = new Room(electronic,furniture,room_element);
     room.RoomEnter();
    }
}
