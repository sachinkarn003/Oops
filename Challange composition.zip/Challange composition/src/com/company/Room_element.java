package com.company;

public class Room_element {
    private int Books_shall;
    private int pen;
    private int Howmanychargerinroom;

    public Room_element(int books_shall, int pen, int howmanychargerinroom) {
        Books_shall = books_shall;
        this.pen = pen;
        Howmanychargerinroom = howmanychargerinroom;
    }
    public void dirty(String clean){
        if(clean == "Clean"){
            System.out.println("Relax");
        }
        else{
            System.out.println("Clean the Room");
        }
    }
}
