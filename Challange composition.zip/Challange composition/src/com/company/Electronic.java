package com.company;

public class Electronic {
    private int bulbs;
    private int Fans;
    private int Charger_point;

    public Electronic(int bulbs, int fans, int charger_point) {
        this.bulbs = bulbs;
        Fans = fans;
        Charger_point = charger_point;
    }
    public void Enter_the_Room(String Light, String Fan){
        if(Light == "on" && Fan == "on"){
            System.out.println("Light is On! or Fan is also on");
        }
        else{
            System.out.println("Light is off! or fan also");
        }

    }

    public int getBulbs() {
        return bulbs;
    }

    public int getFans() {
        return Fans;
    }

    public int getCharger_point() {
        return Charger_point;
    }
}
