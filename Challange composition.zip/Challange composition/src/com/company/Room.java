package com.company;

public class Room {
    private Electronic electronic;
    private Furniture furniture;
    private Room_element room_element;

    public Room(Electronic electronic, Furniture furniture, Room_element room_element) {
        this.electronic = electronic;
        this.furniture = furniture;
        this.room_element = room_element;
    }
    public void RoomEnter(){
        electronic.Enter_the_Room("on","on");
        Enter();
    }
    private void Enter(){
        furniture.color("Bule");
        room_element.dirty("Clean");
    }

}
