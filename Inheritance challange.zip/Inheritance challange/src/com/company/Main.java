package com.company;

public class Main {

    public static void main(String[] args) {
     Specific specific = new Specific(36);
     specific.acclerate(45);
     specific.acclerate(30);
     specific.acclerate(20);
     specific.acclerate(-45);

    }
}
