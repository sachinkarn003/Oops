package com.company;

public class Specific extends Car {
    private int roadserviceMonths;

    public Specific(int roadserviceMonths) {
        super("Outlender", "4wd", 5, 5, 6, false);
        this.roadserviceMonths = roadserviceMonths;
    }

    public void acclerate(int rate) {
        int newVelocity = getCurrentvelocity() + rate;
        if (newVelocity == 0) {
            stop();
            ChangeGear(1);
        }
        else if(newVelocity > 0 &&newVelocity <=10){
            ChangeGear(1);
        }
        else if(newVelocity >10 && newVelocity <=20){
            ChangeGear(2);
        }
        else if(newVelocity > 20 && newVelocity<=30){
            ChangeGear(3);

        }
        else {
            ChangeGear(4);
        }
        if(newVelocity > 0){
            changevelocity(newVelocity,getCurrentdirection());
        }
    }
}