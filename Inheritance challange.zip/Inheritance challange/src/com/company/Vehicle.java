package com.company;

public class Vehicle {
    private String name;
    private String size;

    private int Currentdirection;
    private int Currentvelocity;

    public Vehicle(String name, String size) {
        this.name = name;
        this.size = size;
        this.Currentdirection=0;
        this.Currentvelocity=0;
    }

    public void steer(int direction){
        Currentdirection +=direction;
        System.out.println("vehicle.steer(): at steering  "+Currentdirection+" degrees.");

    }
    public void move(int velocity, int direction){
        Currentdirection=direction;
        Currentvelocity=velocity;
        System.out.println("vehicle.moce(): moving at "+Currentvelocity+" in direction "+Currentdirection);
    }

    public String getName() {
        return name;
    }

    public String getSize() {
        return size;
    }

    public int getCurrentdirection() {
        return Currentdirection;
    }

    public int getCurrentvelocity() {
        return Currentvelocity;
    }
    public void stop(){
        this.Currentvelocity = 0;
    }
}
