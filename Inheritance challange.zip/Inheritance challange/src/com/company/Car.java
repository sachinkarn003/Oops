package com.company;

public class Car extends Vehicle {
        private int wheels;
        private int doors;
        private int Gears;
        private boolean IsManuel;

        private int CurrentGear;

    public Car(String name, String size, int wheels, int doors, int gears, boolean isManuel) {
        super(name, size);
        this.wheels = wheels;
        this.doors = doors;
        Gears = gears;
        IsManuel = isManuel;
        CurrentGear = 1;
    }
    public void ChangeGear(int currentGear){
        this.CurrentGear=currentGear;
        System.out.println("Car.setcurrentGear(): change to "+this.CurrentGear+"gear.");

    }
    public void changevelocity(int speed, int directions){
        move(speed, directions);
        System.out.println("Car.changevelocity(): velocity "+speed +" direction "+directions);
    }
}
