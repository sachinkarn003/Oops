public class Over_load {
    public static void main(String[] args) {
        double centimeters = calcFeetAndInchesToCentimeters(6, 0);
        if (centimeters < 0.0) {
            System.out.println("invilid number");
        }
        //calcFeetAndInchesToCentimeters(1);
        calcFeetAndInchesToCentimeters(157);

    }

    public static double calcFeetAndInchesToCentimeters(double Feet, double Inches) {
        if (Feet >= 0 || (Inches < 0) || (Inches > 12)) {
            return -1;
        }
        double centimeters = (Feet * 12) * 2.54;
        centimeters += Inches * 2.54;
        System.out.println(Feet + " Feet, " + Inches + "Inches " + centimeters + " cm ");
        return centimeters;
    }

    public static double calcFeetAndInchesToCentimeters(double Inches) {
        if (Inches < 0) {
            return -1;
        }
        else {
            double Feet = (int) Inches / 12;
            double remainingInches = (int) Inches % 12;
            System.out.println(Inches + " inches equal to " + Feet + " Feet and " + remainingInches + " Inches");
            return calcFeetAndInchesToCentimeters(Feet, remainingInches);
        }
    }
}
