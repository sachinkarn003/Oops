package com.company;

public class Main {

    public static void main(String[] args) {
	Account karn = new Account();  //"1234", 0.00,"Sachin karn ", "the spiderm@n420gamil.com","8920099026"

		System.out.println(karn.getNumbar());
		System.out.println(karn.getBalance());
	//karn.setNumbar("1234");
	//karn.setBalance(0.00);
	//karn.setName("Sachin karn ");
	//karn.setEmailAddress("the spiderm@n420gmail.com");
	//karn.setNumbar("8920099026");

	    karn.withdrawal(100.0);
	    karn. deposit(50.0);

	    karn.withdrawal(100.0);

	    karn.deposit(51.0);
	    karn.withdrawal(100.0);

    }
}
