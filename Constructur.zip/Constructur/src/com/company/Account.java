package com.company;

public class Account {
    private String numbar;
    private double balance;
    private String name;
    private String EmailAddress;
    private String PhoneNumbar;

    public Account (){
        this("5678",2.5,"SPIDER MAN", "SPIDERM@N420","UNKONW");
        System.out.println("Empty constructor called ");
    }

    public Account(String numbar, double balance, String name, String EmailAddress, String PhoneNumber){
        System.out.println("Account constructor with parameter ");
        this.numbar=numbar;
        this.balance=balance;
        this.name=name;
        this.EmailAddress=EmailAddress;
        this.PhoneNumbar=PhoneNumber;
    }

    public Account(String name, String emailAddress, String phoneNumbar) {
        this("Sachin_karn",100.55,name,emailAddress,phoneNumbar);
    }

    public void deposit(double DepositAccount){
        this.balance+= DepositAccount;
        System.out.println("deposit of "+DepositAccount+ " Made. new balance is "+this.balance);
    }
    public void withdrawal(double Withdrawal){
        if(this.balance - Withdrawal <0){
            System.out.println("only "+this.balance+ " available. whitdrawal not processed ");
        }
        else{
            this.balance -=Withdrawal;
            System.out.println("whitdrawal of "+Withdrawal+" processed. remaning balance "+this.balance);
        }
    }

    public String getNumbar() {
        return numbar;
    }

    public void setNumbar(String numbar) {
        this.numbar = numbar;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        EmailAddress = emailAddress;
    }

    public String getPhoneNumbar() {
        return PhoneNumbar;
    }

    public void setPhoneNumbar(String phoneNumbar) {
        PhoneNumbar = phoneNumbar;
    }
}
