package com.company;

public class DeluxeBurger extends Hamburger {
    public DeluxeBurger() {
        super("Deluxe", 14.54, "White", "Sausage & Bacon");
        super.Hamburgeraddition1("chips",2.75);
        super.Hamburgeraddition2("Drink",1.81);
    }

    @Override
    public void Hamburgeraddition1(String name, double price) {
        System.out.println("Cannot add additional items to a deluxe burger");
    }

    @Override
    public void Hamburgeraddition2(String name, double price) {
        System.out.println("Cannot add additional items to a deluxe burger");
    }

    @Override
    public void Hamburgeraddition3(String name, double price) {
        System.out.println("Cannot add additional items to a deluxe burger");
    }

    @Override
    public void Hamburgeraddition4(String name, double price) {
        System.out.println("Cannot add additional items to a deluxe burger");
    }
}
