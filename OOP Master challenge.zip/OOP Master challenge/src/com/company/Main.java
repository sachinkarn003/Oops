package com.company;

public class Main {

    public static void main(String[] args) {
     Hamburger hamburger = new Hamburger("Basic",3.59,"Sausage","white");
     double price = hamburger.ItimzeHamburger();
     hamburger.Hamburgeraddition1("Tomato",0.27);
     hamburger.Hamburgeraddition2("lettuce",0.37);
     hamburger.Hamburgeraddition3("chese",0.41);
        System.out.println("Total Burger price "+ hamburger.ItimzeHamburger());

        HealthyHamburger healthyHamburger = new HealthyHamburger(5.67,"Bacon ");
        healthyHamburger.addHealthyadditional1("Egg",5.43);
        healthyHamburger.addHealthyadditional1("Letils",3.41);
        System.out.println("Total Burger price = "+ healthyHamburger.ItimzeHamburger());

        DeluxeBurger db = new DeluxeBurger();
        db.Hamburgeraddition1("Should not do this",50.53);
        db.ItimzeHamburger();

    }
}
