package com.company;

public class HealthyHamburger extends Hamburger {
    private String HealthyExtra1Name;
    private double HealthyExtra1price;
    private String HealthyExtra2Name;
    private double HealthyExtra2price;

    public HealthyHamburger( double price,  String meet) {
        super("Healthy", price, "Brown rey", meet);
    }
    public void addHealthyadditional1(String name, double price){
        this.HealthyExtra1Name = name;
        this.HealthyExtra1price = price;
}
    public void addHealthyadditional2(String name, double price){
        this.HealthyExtra1Name = name;
        this.HealthyExtra1price = price;
    }

    @Override
    public double ItimzeHamburger() {
        double hamburgerprice = super.ItimzeHamburger();
        if(this.HealthyExtra1Name != null){
            hamburgerprice += this.HealthyExtra1price;
            System.out.println("Added "+this.HealthyExtra1Name+" for an extra "+ this.HealthyExtra1price);
        }
        if(this.HealthyExtra2Name != null){
            hamburgerprice += this.HealthyExtra1price;
            System.out.println("Added "+this.HealthyExtra2Name+" for an extra "+ this.HealthyExtra2price);
        }
        return hamburgerprice;
    }

}
