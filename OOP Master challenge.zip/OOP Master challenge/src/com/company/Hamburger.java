package com.company;

public class Hamburger {
    private String name;
    private double price;
    private String TypeOfRoll;
    private  String meet;

    private String additional1Name;
    private double additional1Price;

    private String additional2Name;
    private double additional2Price;

    private String additional3Name;
    private double additional3Price;

    private String additional4Name;
    private double additional4Price;

    public Hamburger(String name, double price, String typeOfRoll, String meet) {
        this.name = name;
        this.price = price;
        TypeOfRoll = typeOfRoll;
        this.meet = meet;
    }

    public void Hamburgeraddition1(String name,double price){
        this.additional1Name= name;
        this.additional1Price=price;
    }

    public void Hamburgeraddition2(String name,double price){
        this.additional2Name= name;
        this.additional2Price=price;
    }

    public void Hamburgeraddition3(String name,double price){
        this.additional3Name= name;
        this.additional3Price=price;
    }

    public void Hamburgeraddition4(String name,double price){
        this.additional4Name= name;
        this.additional4Price=price;
    }
    public double ItimzeHamburger(){
        double hamburgerprice = this.price;
        System.out.println(this.name+" hamburger "+" on a "+this.TypeOfRoll+" Roll "+" with "+this.meet + "price is "+this.price);
        if(this.additional1Name !=null){
            hamburgerprice +=this.additional1Price;
            System.out.println("Added "+this.additional1Name +" for an extra "+this.additional1Price);
        }
        if(this.additional2Name !=null){
            hamburgerprice +=this.additional2Price;
            System.out.println("Added "+this.additional2Name +" for an extra "+this.additional2Price);
        }
        if(this.additional1Name !=null){
            hamburgerprice +=this.additional3Price;
            System.out.println("Added "+this.additional3Name +" for an extra "+this.additional3Price);
        }
        if(this.additional4Name !=null){
            hamburgerprice +=this.additional4Price;
            System.out.println("Added "+this.additional4Name +" for an extra "+this.additional4Price);
        }
        return hamburgerprice;
    }
}
